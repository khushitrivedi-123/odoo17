{
    'name': 'Custom Website Form',
    'version': '17.0',
    'depends': ['website'],
    'data': [
        'views/form_template.xml',
        'views/thank_you_template.xml',
    ],
    'installable': True,
    'application': False,
}
