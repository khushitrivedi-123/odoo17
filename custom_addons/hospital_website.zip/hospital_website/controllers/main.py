from odoo import http
from odoo.http import request

class CustomFormController(http.Controller):

    @http.route('/my/form', type='http', auth='public', website=True)
    def render_form(self, **kwargs):
        return request.render('your_module_name.form_template')

    @http.route('/my/form/submit', type='http', auth='public', website=True)
    def submit_form(self, **post):
        # Replace 'res.partner' with your desired model
        request.env['res.partner'].sudo().create({
            'name': post.get('name'),
            'email': post.get('email'),
        })
        return request.redirect('/thank-you')
