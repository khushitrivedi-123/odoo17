from . import hospital_patient
from . import hospital_physician
from . import hospital_speciality
from . import hospital_treatment
from . import hospital_disease
from . import hospital_diagnosis
from . import sale_order