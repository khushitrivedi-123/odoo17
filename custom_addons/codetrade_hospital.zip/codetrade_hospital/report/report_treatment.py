# from odoo import models, api
#
# class HospitalTreatmentReport(models.AbstractModel):
#     _name = 'report.hospital_treatment.report_hospital_treatment_document'
#     _description = 'Hospital Treatment PDF Report'
#
#     @api.model
#     def _get_report_values(self, docids, data=None):
#         docs = self.env['hospital.treatment'].browse(docids)
#         return {
#             'docs': docs
#         }

